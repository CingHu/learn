from thrift.transport import TSocket
from vrouter_rpc import vrouter_rpc
from vrouter_rpc.ttypes import *


class VRCLI:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.transport = None
        self.client = None

    def connect(self):
        socket = TSocket.TSocket(self.host, self.port)
        self.transport = TTransport.TBufferedTransport(socket)
        protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = vrouter_rpc.Client(protocol)
        try:
            self.transport.open()
            return 0
        except TTransport.TTransportException:
            return -1

    def close(self):
        if self.transport is not None:
            self.transport.close()

    def vgw_list(self):
        if self.client is not None:
            return self.client.vgw_list()
        else:
            return None

    def flowtable_list(self, vni):
        if self.client is not None:
            return self.client.flowtable_list(vni)
        else:
            return None

    def subnet_list(self, vni):
        if self.client is not None:
            return self.client.subnet_list(vni)
        else:
            return None
