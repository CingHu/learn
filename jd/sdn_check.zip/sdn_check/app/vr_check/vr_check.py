import logging
from cliff.help import *
from cc import cc_util
from libs import ops_lib
import vr_cli


def do_vr_check(vpc_detail, subnet_detail, vr_binding_list):
    # ================================ Check VR runtime information ================================
    vpc_bound_vr_hosts = []
    for vr_host_info in vr_binding_list:
        vpc_bound_vr_hosts.append(vr_host_info.ip['mgmt'])

    vrchecker = VRChecker(vpc_bound_vr_hosts)
    vrchecker.connect()

    print(ops_lib.BColors.HEADER + "======================    " + 'Check VR Runtime Data' + "    ======================" + ops_lib.BColors.ENDC)
    # --------------------------------- Check VPC on VR ---------------------------------
    vrchecker.check_vpc([vpc_detail.vni])

    # --------------------------------- Check Subnet on VR ---------------------------------
    vrchecker.check_subnet(vpc_detail.vni, subnet_detail)

    # --------------------------------- All Checking finished ---------------------------------
    vrchecker.close()


def do_dr_check(dr_list, vr_binding_list, fip_detail):
    # ================================ Check DR runtime information ================================
    if dr_list and vr_binding_list and fip_detail:
        dr_hosts = []
        for dr_host_info in dr_list:
            dr_hosts.append(dr_host_info.ip['mgmt'])

        drchecker = DRChecker(dr_hosts)
        drchecker.connect()

        print(ops_lib.BColors.HEADER + "======================    " + 'Check DR Runtime Data' + "    ======================" + ops_lib.BColors.ENDC)
        # --------------------------------- Check floating IP on DR ---------------------------------
        dr_to_vr_hosts = []
        for vr_host_info in vr_binding_list:
            dr_to_vr_hosts.append(vr_host_info.ip['Dv'])

        drchecker.check_dr_floatingip(fip_detail.floating_ip_address, set(dr_to_vr_hosts))
        # --------------------------------- All Checking finished ---------------------------------
        drchecker.close()


class DRChecker:
    def __init__(self, dr_hosts):
        self.dr_hosts = dr_hosts
        self.port = 9090
        self.drclis = []

    def connect(self):
        for dr_host in self.dr_hosts:
            drcli = vr_cli.VRCLI(dr_host, self.port)
            err = drcli.connect()
            if err == -1:
                print(ops_lib.BColors.FAIL + '{ FAIL }' + ops_lib.BColors.ENDC + ' Cannot connect to DR %s' % dr_host)
                continue
            else:
                self.drclis.append(drcli)

    def close(self):
        for drcli in self.drclis:
            drcli.close()

    def check_dr_floatingip(self, floatingip, vrhost_set):
        for drcli in self.drclis:
            fip_vr_map = {}
            flows = drcli.flowtable_list(0)
            for flow in flows:
                if fip_vr_map.get(flow.dst_ip) is None:
                    runtime_vr_set = {flow.nh_ip}
                    fip_vr_map[flow.dst_ip] = runtime_vr_set
                else:
                    fip_vr_map[flow.dst_ip].add(flow.nh_ip)

            if fip_vr_map.get(floatingip) is None:
                print(ops_lib.BColors.FAIL + '{ FAIL }' + ops_lib.BColors.ENDC +
                      ' Floating IP %s not found on DR host %s' % (floatingip, drcli.host))
            else:
                runtime_vr_set = fip_vr_map[floatingip]
                if runtime_vr_set == vrhost_set:
                    print(ops_lib.BColors.OKGREEN + '{ PASS }' + ops_lib.BColors.ENDC +
                          ' Floating IP %s found on DR host %s' % (floatingip, drcli.host))
                else:
                    print(ops_lib.BColors.FAIL + '{ FAIL }' + ops_lib.BColors.ENDC +
                          ' on DR host %s, Floating IP %s VR list doesn\'t match ' % (drcli.host, floatingip))
                    print(' Runtime VR List: ', list(runtime_vr_set))
                    print(' Expected VR List: ', list(vrhost_set))


class VRChecker:
    def __init__(self, vr_hosts):
        self.vr_hosts = vr_hosts
        self.port = 9090
        self.vrclis = []

    def connect(self):
        for vr_host in self.vr_hosts:
            vrcli = vr_cli.VRCLI(vr_host, self.port)
            err = vrcli.connect()
            if err == -1:
                print(ops_lib.BColors.FAIL + '{ FAIL }' + ops_lib.BColors.ENDC + ' Cannot connect to VR %s' % vr_host)
                continue
            else:
                self.vrclis.append(vrcli)

    def close(self):
        for vrcli in self.vrclis:
            vrcli.close()

    def check_vpc(self, vnis):
        for vrcli in self.vrclis:
            tmpvni_list = []
            vgws = vrcli.vgw_list()
            for vgw in vgws:
                tmpvni_list.append(vgw.vni)
            for vni in vnis:
                if int(vni) in tmpvni_list:
                    print(ops_lib.BColors.OKGREEN + '{ PASS }' + ops_lib.BColors.ENDC + ' Find VPC %s on VR host %s'
                          % (vni, vrcli.host))
                else:
                    print(ops_lib.BColors.FAIL + '{ FAIL }' + ops_lib.BColors.ENDC + ' VNI %s not found on VR host %s'
                          % (vni, vrcli.host))

    def check_subnet(self, vni, expected_subnet):
        for vrcli in self.vrclis:
            subnets_on_vr = vrcli.subnet_list(vni)
            found_expected_subnet = False
            for subnet in subnets_on_vr:
                if subnet.ipaddr == expected_subnet.gateway_ip\
                        and subnet.mac == expected_subnet.gateway_mac\
                        and subnet.rtt_id == expected_subnet.route_table_id\
                        and subnet.acl_id == expected_subnet.acl_id:
                    found_expected_subnet = True
                    print(ops_lib.BColors.OKGREEN + '{ PASS }' + ops_lib.BColors.ENDC + ' Find Subnet %s %s on VR host %s'
                          % (expected_subnet.id, expected_subnet.gateway_ip, vrcli.host))
                    break
            if not found_expected_subnet:
                print(ops_lib.BColors.FAIL + '{ FAIL }' + ops_lib.BColors.ENDC + ' Subnet %s not found on VR host %s'
                      % (expected_subnet.id, vrcli.host))


class AppVRCheck(Command):
    log = logging.getLogger(__name__)

    def get_parser(self, prog_name):
        parser = super(AppVRCheck, self).get_parser(prog_name)
        parser.add_argument('--tenant_id', help='Tenant ID')
        parser.add_argument('--floatingip', help='Floating IP of an instance')
        parser.add_argument('--instanceid', help='ID of an instance')
        parser.add_argument('--cc_url', help='CC Server Url')

        return parser

    def take_action(self, parsed_args):
        parsed_args = ops_lib.cc_parameters_check(parsed_args)
        if not parsed_args:
            return

        (port_detail, fip_detail, subnet_detail) = cc_util.retrieve_basic_info(parsed_args.tenant_id, parsed_args.cc_url,
                                                                               instanceid=parsed_args.instanceid,
                                                                               floatingip=parsed_args.floatingip)
        if not port_detail:
            if fip_detail:
                print('Floating IP %s does not associated with a port' % parsed_args.floatingip)
            else:
                print('Cannot find port for the query, check your input parameters')
        else:
            cc_util_instance = cc_util.CCUtil(parsed_args.cc_url)
            vpc_detail = cc_util_instance.retrieve_vpc_detail(parsed_args.tenant_id, subnet_detail.vpc_id)
            vr_binding_list = cc_util_instance.retrieve_vrbinding_detail(subnet_detail.vpc_id)
            dr_list = cc_util_instance.retrieve_dr_host_list()

            do_vr_check(vpc_detail, subnet_detail, vr_binding_list)
            do_dr_check(dr_list, vr_binding_list, fip_detail)

