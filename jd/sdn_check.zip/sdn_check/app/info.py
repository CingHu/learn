import logging
from cliff.help import *
from cc import cc_util
from libs import ops_lib
import subprocess
import os

cli_cmd = "ccs"


class CCLI:
    def __init__(self, tenant_id, cc_srv_url, cli_cmd):
        self.cc_srv_url = cc_srv_url
        self.cli_cmd = cli_cmd

        os.environ["CC_TENANT_ID"] = tenant_id
        os.environ["CC_SERVER_URL"] = self.cc_srv_url

    def show_port_detail(self, port_id):
        if port_id is not None:
            cmdstr = self.cli_cmd + ' port-show ' + port_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_subnet_detail(self, subnet_id):
        if subnet_id is not None:
            cmdstr = self.cli_cmd + ' subnet-show ' + subnet_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_securitygroup_detail(self, sg_id):
        if sg_id is not None:
            cmdstr = self.cli_cmd + ' security-group-show ' + sg_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_securitygroup_rule_detail(self, sg_id):
        if sg_id is not None:
            cmdstr = self.cli_cmd + ' security-group-rule-list' + ' --securitygroup-id ' + sg_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_acl_rules_detail(self, acl_id):
        if acl_id:
            cmdstr = self.cli_cmd + ' acl-rule list ' + acl_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_fip_detail(self, fip_id):
        if fip_id is not None:
            cmdstr = self.cli_cmd + ' floatingip-show ' + fip_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_vr_host_detail(self, vpc_id):
        if vpc_id is not None:
            cmdstr = self.cli_cmd + ' host-list-binding-router ' + vpc_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None


def display_vpc_info(ccurl, tenant_id, port_detail=None, subnet_detail=None, fip_detail=None):
    ccli = CCLI(tenant_id, ccurl, cli_cmd)

    if port_detail and subnet_detail:
        port_out, err = ccli.show_port_detail(port_detail.id)
        ops_lib.print_info("Port Info", port_out)

        subnet_out, err = ccli.show_subnet_detail(port_detail.subnet_id)
        ops_lib.print_info("Subnet Info", subnet_out)

        acl_out, err = ccli.show_acl_rules_detail(subnet_detail.acl_id)
        ops_lib.print_info("ACL Rules Info", acl_out)

        show_sg_details = []
        for security_group_id in port_detail.securitygroup_ids:
            sg_out, err = ccli.show_securitygroup_detail(security_group_id)
            show_sg_details.append(sg_out)
            sgr_out, err = ccli.show_securitygroup_rule_detail(security_group_id)
            show_sg_details.append(sgr_out)
        ops_lib.print_info("SecurityGroup Info", show_sg_details)

    if fip_detail:
        fip_out, err = ccli.show_fip_detail(fip_detail.id)
        ops_lib.print_info("Floating IP Info", fip_out)

    if subnet_detail:
        host_out, err = ccli.show_vr_host_detail(subnet_detail.vpc_id)
        ops_lib.print_info("VR Host Info", host_out)


class AppDisplayInfo(Command):
    log = logging.getLogger(__name__)

    def get_parser(self, prog_name):
        parser = super(AppDisplayInfo, self).get_parser(prog_name)
        parser.add_argument('--tenant_id', help='Tenant ID')
        parser.add_argument('--floatingip', help='Floating IP of an instance')
        parser.add_argument('--instanceid', help='ID of an instance')
        parser.add_argument('--cc_url', help='CC Server Url')

        return parser

    def take_action(self, parsed_args):
        parsed_args = ops_lib.cc_parameters_check(parsed_args)
        if not parsed_args:
            return

        (port_detail, fip_detail, subnet_detail) = cc_util.retrieve_basic_info(parsed_args.tenant_id, parsed_args.cc_url,
                                                                               instanceid=parsed_args.instanceid,
                                                                               floatingip=parsed_args.floatingip)
        if not port_detail:
            if fip_detail:
                print('Floating IP %s does not associated with a port' % parsed_args.floatingip)
            else:
                print('Cannot find port for the query, check your input parameters')

        display_vpc_info(parsed_args.cc_url, parsed_args.tenant_id,
                         port_detail=port_detail,
                         subnet_detail=subnet_detail,
                         fip_detail=fip_detail)

