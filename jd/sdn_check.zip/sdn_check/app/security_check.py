import socket
import struct
import logging
from cliff.help import *
from cc import cc_util
from libs import ops_lib


def address_in_network(ip, net):
    ipaddr = struct.unpack('!I', socket.inet_aton(ip))[0]
    netaddr, bits = net.split('/')
    netmask = 0
    if 32 >= int(bits) > 0:
        netmask = (((2L << int(bits)-1) - 1) << (32 - int(bits)))
    subnet = struct.unpack('!I', socket.inet_aton(netaddr))[0]
    # print(hex(netmask))
    # print(hex(ipaddr & netmask), hex(subnet & netmask))
    return ipaddr & netmask == subnet & netmask


def protocol_match(checker_protocol, rule_protocol):
    return rule_protocol == 'all' or checker_protocol == rule_protocol


def acl_port_match(checker_src_port, checker_dest_port, rule):
    match = False
    if rule.protocol == 'all' or rule.protocol == 'icmp':
        match = True
    elif rule.direction == 'ingress':
        match = rule.port_end >= checker_dest_port >= rule.port_start
    elif rule.direction == 'egress':
        match = (checker_src_port != 0 and rule.port_end >= checker_src_port >= rule.port_start)\
                or (checker_src_port == 0 and rule.port_end == 65535 and rule.port_start == 1)
    return match


def acl_ip_match(checker_src_ip, checker_dest_ip, rule):
    match = False
    if rule.direction == 'ingress':
        match = address_in_network(checker_dest_ip, rule.ip_prefix)
    elif rule.direction == 'egress':
        match = address_in_network(checker_src_ip, rule.ip_prefix)
    return match


def securitygroup_port_match(checker_dest_port, rule):
    return rule.protocol == 'all' or rule.protocol == 'icmp' or rule.port_end >= checker_dest_port >= rule.port_start


def securitygroup_ip_match(checker_src_ip, checker_dest_ip, rule):
    match = False
    if rule.direction == 'ingress':
        match = address_in_network(checker_src_ip, rule.ip_prefix)
    elif rule.direction == 'egress':
        match = address_in_network(checker_dest_ip, rule.ip_prefix)
    return match


def check_securitygroup(sg_rules_map, check_list):
    all_rules_list = []
    for (sg, rules) in sg_rules_map.items():
        all_rules_list += rules
    for check_item in check_list:
        matched_rule = None
        item = check_item['item']
        for rule in all_rules_list:
            if item.get('direction') == rule.direction\
                    and protocol_match(item.get('protocol'), rule.protocol)\
                    and securitygroup_ip_match(item.get('src_ip'), item.get('dst_ip'), rule)\
                    and securitygroup_port_match(item.get('dst_port'), rule):
                matched_rule = rule
                break
        check_item['rule'] = matched_rule

    return check_list


def check_acl(acl_rules_list, check_list):
    sorted_rules = sorted(acl_rules_list, key=lambda x: x.priority, reverse=False)
    for check_item in check_list:
        ingress_action = 'Unknown'
        egress_action = 'Unknown'
        ingress_matched_rule = None
        egress_matched_rule = None

        item = check_item['item']
        for rule in sorted_rules:
            if (rule.direction == 'ingress' and ingress_action != 'Unknown')\
                    or (rule.direction == 'egress' and egress_action != 'Unknown'):
                continue

            if protocol_match(item['protocol'], rule.protocol)\
                    and acl_ip_match(item['src_ip'], item['dst_ip'], rule)\
                    and acl_port_match(item['src_port'], item['dst_port'], rule):
                if rule.direction == 'ingress':
                    ingress_matched_rule = rule.id
                    ingress_action = rule.action
                elif rule.direction == 'egress':
                    egress_matched_rule = rule.id
                    egress_action = rule.action

        check_item['result'] = {}
        check_item['result']['ingress_action'] = ingress_action
        check_item['result']['egress_action'] = egress_action

        check_item['result']['ingress_rule'] = ingress_matched_rule
        check_item['result']['egress_rule'] = egress_matched_rule

    return check_list


def do_acl_check(floatingip, acl_rules_list):
    standard_acl_check_list = [
        {'title': 'PING',
         'description': 'Ping from Internet to VM',
         'item': {'protocol': 'icmp', 'src_ip': '0.0.0.0', 'src_port': 0,
                  'dst_ip': floatingip, 'dst_port': 0}
         },
        {'title': 'SSH',
         'description': 'SSH from Internet to VM',
         'item': {'protocol': 'tcp', 'src_ip': '0.0.0.0', 'src_port': 0,
                  'dst_ip': floatingip, 'dst_port': 22},
         },
        {'title': 'DNS - UDP',
         'description': 'UDP DNS from VM to Internet',
         'item': {'protocol': 'udp', 'src_ip': floatingip, 'src_port': 0,
                  'dst_ip': '0.0.0.0', 'dst_port': 53}
         },
        {'title': 'DNS - TCP',
         'description': 'TCP DNS from VM to Internet',
         'item': {'protocol': 'tcp', 'src_ip': floatingip, 'src_port': 0,
                  'dst_ip': '0.0.0.0', 'dst_port': 53}
         },
        {'title': 'HTTP',
         'description': 'HTTP from Internet to VM',
         'item': {'protocol': 'tcp', 'src_ip': '0.0.0.0', 'src_port': 0,
                  'dst_ip': floatingip, 'dst_port': 80}
         },
        {'title': 'Remote Desktop',
         'description': 'Remote Desktop from Internet to VM',
         'item': {'protocol': 'tcp', 'src_ip': '0.0.0.0', 'src_port': 0,
                  'dst_ip': floatingip, 'dst_port': 3389}
         },
    ]

    if acl_rules_list:
        print(ops_lib.BColors.HEADER + "======================    " + 'Check ACL' + "    ======================" + ops_lib.BColors.ENDC)
        result = check_acl(acl_rules_list, standard_acl_check_list)
        for checker in result:
            if checker.get('description', None):
                print('------------------------------------' + checker['description'] + '------------------------------------')

            if checker['result']['ingress_action'] == 'accept' and checker['result']['egress_action'] == 'accept':
                print(ops_lib.BColors.OKGREEN + '{ PASS }' + ops_lib.BColors.ENDC +
                      ' (%s), Ingress[ %s ], Egress[ %s ], (%s, %s)'
                      % (checker['title'], checker['result']['ingress_action'], checker['result']['egress_action'],
                         checker['result']['ingress_rule'], checker['result']['egress_rule']))
            else:
                print(ops_lib.BColors.WARNING + '{ DENY }' + ops_lib.BColors.ENDC + ' (%s)' % checker['title'])
                print('         ' + 'Ingress[ %s ] (%s)' % (checker['result']['ingress_action'], checker['result']['ingress_rule']))
                print('         ' + 'Egress [ %s ] (%s)' % (checker['result']['egress_action'], checker['result']['egress_rule']))

                # print(ops_lib.BColors.WARNING + '{ DENY }' + ops_lib.BColors.ENDC +
                #       ' (%s), Ingress[ %s ], Egress[ %s ], (%s, %s)'
                #       % (checker['title'], checker['result']['ingress_action'], checker['result']['egress_action'],
                #          checker['result']['ingress_rule'], checker['result']['egress_rule']))
            print('')


def do_securitygroup_check(cc_sg_rules_map):
    standard_security_check_list = [
        {'title': 'PING',
         'description': 'Ping from Internet to VM',
         'item': {'protocol': 'icmp', 'direction': 'ingress', 'src_ip': '0.0.0.0', 'dst_port': 0}
         },
        {'title': 'PING INTERNET',
         'description': 'Ping from VM to Internet',
         'item': {'protocol': 'icmp', 'direction': 'egress', 'dst_ip': '0.0.0.0', 'dst_port': 0}
         },
        {'title': 'DNS UDP',
         'description': 'UDP DNS from VM to Internet',
         'item': {'protocol': 'udp', 'direction': 'egress', 'dst_ip': '0.0.0.0', 'dst_port': 53}
         },
        {'title': 'DNS TCP',
         'description': 'TCP DNS from VM to Internet',
         'item': {'protocol': 'tcp', 'direction': 'egress', 'dst_ip': '0.0.0.0', 'dst_port': 53}
         },
        {'title': 'SSH',
         'description': 'SSH from Internet to VM',
         'item': {'protocol': 'tcp', 'direction': 'ingress', 'src_ip': '0.0.0.0', 'dst_port': 22}
         },
        {'title': 'HTTP',
         'description': 'HTTP from Internet to VM',
         'item': {'protocol': 'tcp', 'direction': 'ingress', 'src_ip': '0.0.0.0', 'dst_port': 80}
         },
        {'title': 'Remote Desktop',
         'description': 'Remote Desktop from Internet to VM',
         'item': {'protocol': 'tcp', 'direction': 'ingress', 'src_ip': '0.0.0.0', 'dst_port': 3389}
         },
    ]
    print(ops_lib.BColors.HEADER + "======================    " + 'Check Security Groups' + "    ======================" + ops_lib.BColors.ENDC)
    result = check_securitygroup(cc_sg_rules_map, standard_security_check_list)
    for checker in result:
        if checker.get('description', None):
            print('------------------------------------' + checker['description'] + '------------------------------------')
        if checker.get('rule', None):
            print(ops_lib.BColors.OKGREEN + '{ PASS }' + ops_lib.BColors.ENDC +
                  ' Rule [ %s ]' % checker['rule'].id)
        else:
            print(ops_lib.BColors.WARNING + '{ DENY }' + ops_lib.BColors.ENDC)
        print('')


class AppSecurityCheck(Command):
    logger = logging.getLogger(__name__)

    def get_parser(self, prog_name):
        parser = super(AppSecurityCheck, self).get_parser(prog_name)
        parser.add_argument('--tenant_id', help='Tenant ID')
        parser.add_argument('--floatingip', help='Floating IP of an instance')
        parser.add_argument('--instanceid', help='ID of an instance')
        parser.add_argument('--cc_url', help='CC Server Url')

        return parser

    def take_action(self, parsed_args):
        hdlr = logging.FileHandler('/var/tmp/myapp.log')
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        hdlr.setFormatter(formatter)
        self.logger.addHandler(hdlr)
        self.logger.setLevel(logging.DEBUG)

        parsed_args = ops_lib.cc_parameters_check(parsed_args)
        if not parsed_args:
            return

        (port_detail, fip_detail, subnet_detail) = cc_util.retrieve_basic_info(parsed_args.tenant_id, parsed_args.cc_url,
                                                                               instanceid=parsed_args.instanceid,
                                                                               floatingip=parsed_args.floatingip)
        if not port_detail:
            if fip_detail:
                print('Floating IP %s does not associated with a port' % parsed_args.floatingip)
            else:
                print('Cannot find port for the query, check your input parameters')
        else:
            sg_rules_map = {}
            cc_util_instance = cc_util.CCUtil(parsed_args.cc_url)
            acl_rules_list = cc_util_instance.retrieve_aclrules_detail(parsed_args.tenant_id, subnet_detail.acl_id)

            for security_group_id in port_detail.securitygroup_ids:
                sg_rules_list = cc_util_instance.retrieve_sgrules_detail(parsed_args.tenant_id, security_group_id)
                sg_rules_map[security_group_id] = sg_rules_list

            do_securitygroup_check(sg_rules_map)
            if fip_detail:
                do_acl_check(fip_detail.floating_ip_address, acl_rules_list)
