import logging
from cliff.help import *
from cc import cc_util, lb_util
from libs import ops_lib
import subprocess
import os

cli_cmd = "ccs"


class CCLI:
    def __init__(self, tenant_id, cc_srv_url, cli_cmd):
        self.cc_srv_url = cc_srv_url
        self.cli_cmd = cli_cmd

        os.environ["CC_TENANT_ID"] = tenant_id
        os.environ["CC_SERVER_URL"] = self.cc_srv_url

    def show_port_detail(self, port_id):
        if port_id is not None:
            cmdstr = self.cli_cmd + ' port-show ' + port_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_subnet_detail(self, subnet_id):
        if subnet_id is not None:
            cmdstr = self.cli_cmd + ' subnet-show ' + subnet_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_securitygroup_detail(self, sg_id):
        if sg_id is not None:
            cmdstr = self.cli_cmd + ' security-group-show ' + sg_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_securitygroup_rule_detail(self, sg_id):
        if sg_id is not None:
            cmdstr = self.cli_cmd + ' security-group-rule-list' + ' --securitygroup-id ' + sg_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_acl_rules_detail(self, acl_id):
        if acl_id:
            cmdstr = self.cli_cmd + ' acl-rule list ' + acl_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_fip_detail(self, fip_id):
        if fip_id is not None:
            cmdstr = self.cli_cmd + ' floatingip-show ' + fip_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None

    def show_vr_host_detail(self, vpc_id):
        if vpc_id is not None:
            cmdstr = self.cli_cmd + ' host-list-binding-router ' + vpc_id
            cmd = cmdstr.split()

            p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
            return p.communicate()
        else:
            return None, None


def display_vpc_info(ccurl, tenant_id, port_detail=None, subnet_detail=None, fip_detail=None):
    ccli = CCLI(tenant_id, ccurl, cli_cmd)

    if port_detail and subnet_detail:
        port_out, err = ccli.show_port_detail(port_detail.id)
        ops_lib.print_info("Port Info", port_out)

        subnet_out, err = ccli.show_subnet_detail(port_detail.subnet_id)
        ops_lib.print_info("Subnet Info", subnet_out)

        acl_out, err = ccli.show_acl_rules_detail(subnet_detail.acl_id)
        ops_lib.print_info("ACL Rules Info", acl_out)

        show_sg_details = []
        for security_group_id in port_detail.securitygroup_ids:
            sg_out, err = ccli.show_securitygroup_detail(security_group_id)
            show_sg_details.append(sg_out)
            sgr_out, err = ccli.show_securitygroup_rule_detail(security_group_id)
            show_sg_details.append(sgr_out)
        ops_lib.print_info("SecurityGroup Info", show_sg_details)

    if fip_detail:
        fip_out, err = ccli.show_fip_detail(fip_detail.id)
        ops_lib.print_info("Floating IP Info", fip_out)

    if subnet_detail:
        host_out, err = ccli.show_vr_host_detail(subnet_detail.vpc_id)
        ops_lib.print_info("VR Host Info", host_out)


class AppLBInfo(Command):
    log = logging.getLogger(__name__)

    def get_parser(self, prog_name):
        parser = super(AppLBInfo, self).get_parser(prog_name)
        parser.add_argument('--tenant_id', help='Tenant ID')
        parser.add_argument('--alb_id', help='ID of an application LB instance')
        parser.add_argument('--cc_url', help='CC Server Url')
        parser.add_argument('--lb_url', help='LB Server Url')

        return parser

    def take_action(self, parsed_args):
        parsed_args = ops_lib.lb_parameters_check(parsed_args)
        if not parsed_args:
            return

        lb_util_instance = lb_util.LBUtil(parsed_args.lb_url)
        alb_detail = lb_util_instance.retrieve_alb_detail(parsed_args.tenant_id, parsed_args.alb_id)
        ops_lib.print_info("Alb Info", alb_detail.to_json())

        alb_instances = lb_util_instance.retrieve_alb_instances(parsed_args.tenant_id, parsed_args.alb_id)
        print_output = []
        for instance in alb_instances:
            print_output.append(instance.to_json())
        ops_lib.print_info("Alb Instances Info", print_output)

        listeners_list = lb_util_instance.retrieve_listeners(parsed_args.tenant_id, parsed_args.alb_id)
        if listeners_list:
            for listener in listeners_list:
                ops_lib.print_info("Listner Info", listener.to_json())

                backend_detail = lb_util_instance.retrieve_backend_detail(parsed_args.tenant_id, listener.backend_id)
                ops_lib.print_info("Backend Info", backend_detail.to_json())

                targets_list = lb_util_instance.retrieve_targets(parsed_args.tenant_id, backend_detail.target_group_id)
                print_output = []
                if targets_list:
                    for target in targets_list:
                        print_output.append(target.to_json())
                ops_lib.print_info("Targets Info", print_output)

                health_check_info = lb_util_instance.retrieve_healthcheck_detail(parsed_args.tenant_id, backend_detail.health_check_id)
                ops_lib.print_info("Health Check Info", health_check_info.to_json())
