import cc_http_client
import lb_objs


class LBUtil:
    def __init__(self, lb_srv_url):
        self.cc_client_instance = cc_http_client.CCHTTPClient(lb_srv_url)

    def retrieve_alb_detail(self, tenant_id, alb_id, **kwargs):
        alb_detail_info = None
        lb_response = None
        if tenant_id and alb_id:
            lb_response = self.cc_client_instance.do_http_request(
                'DescribeAlbs', {"tenant_id": tenant_id,
                                        "filter": [{"field": "ids", "value": [alb_id]}]})
        if lb_response and lb_response.code == 0 and lb_response.data['total_count'] > 0:
            alb_detail_info = lb_objs.AlbDetailInfo(**lb_response.data['elements'][0])

        return alb_detail_info

    def retrieve_alb_instances(self, tenant_id, alb_id, **kwargs):
        alb_instances = None
        lb_response = None
        if tenant_id and alb_id:
            lb_response = self.cc_client_instance.do_http_request(
                'DescribeAlbInstances', {"tenant_id": tenant_id,
                                        "filter": [{"field": "alb_id", "value": alb_id}]})
        if lb_response and lb_response.code == 0 and lb_response.data['total_count'] > 0:
            alb_instances = []
            for data in lb_response.data['elements']:
                alb_instance_info = lb_objs.AlbInstanceInfo(**data)
                alb_instances.append(alb_instance_info)

        return alb_instances

    def retrieve_backend_detail(self, tenant_id, backend_id, **kwargs):
        backend_detail_info = None
        lb_response = None
        if tenant_id and backend_id:
            lb_response = self.cc_client_instance.do_http_request(
                'DescribeBackends', {"tenant_id": tenant_id,
                                        "filter": [{"field": "ids", "value": [backend_id]}]})
        if lb_response and lb_response.code == 0 and lb_response.data['total_count'] > 0:
            backend_detail_info = lb_objs.BackendDetailInfo(**lb_response.data['elements'][0])

        return backend_detail_info

    def retrieve_listeners(self, tenant_id, alb_id, **kwargs):
        listeners_list = None
        lb_response = None
        if tenant_id and alb_id:
            lb_response = self.cc_client_instance.do_http_request(
                'DescribeListeners', {"tenant_id": tenant_id,
                                        "filter": [{"field": "alb_id", "value": alb_id}]})
        if lb_response and lb_response.code == 0 and lb_response.data['total_count'] > 0:
            listeners_list = []
            for data in lb_response.data['elements']:
                listener_detail_info = lb_objs.ListenerDetailInfo(**data)
                listeners_list.append(listener_detail_info)

        return listeners_list

    def retrieve_targets(self, tenant_id, targetgroup_id, **kwargs):
        targets_list = None
        lb_response = None
        if tenant_id and targetgroup_id:
            lb_response = self.cc_client_instance.do_http_request(
                'DescribeTargets', {"tenant_id": tenant_id,
                                        "filter": [{"field": "target_group_id", "value": targetgroup_id}]})
        if lb_response and lb_response.code == 0 and lb_response.data['total_count'] > 0:
            targets_list = []
            for data in lb_response.data['elements']:
                target_info = lb_objs.TargetInfo(**data)
                targets_list.append(target_info)

        return targets_list

    def retrieve_healthcheck_detail(self, tenant_id, hc_id, **kwargs):
        healthcheck_info = None
        lb_response = None
        if tenant_id and hc_id:
            lb_response = self.cc_client_instance.do_http_request(
                'DescribeHealthChecks', {"tenant_id": tenant_id,
                                        "filter": [{"field": "ids", "value": [hc_id]}]})
        if lb_response and lb_response.code == 0 and lb_response.data['total_count'] > 0:
                healthcheck_info = lb_objs.HealthCheckInfo(**lb_response.data['elements'][0])

        return healthcheck_info
