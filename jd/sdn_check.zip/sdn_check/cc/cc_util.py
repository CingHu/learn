import cc_http_client
import cc_objs


def retrieve_basic_info(tenant_id, cc_url, instanceid=None, floatingip=None):
    port_detail = None
    fip_detail = None
    subnet_detail = None

    cc_util_instance = CCUtil(cc_url)
    if instanceid:
        port_detail = cc_util_instance.retrieve_port_detail(tenant_id=tenant_id, instanceid=instanceid)
        if port_detail:
            fip_detail = cc_util_instance.retrieve_floatingip_detail(tenant_id=tenant_id,
                                                                     subnet_id=port_detail.subnet_id,
                                                                     fixed_ip=port_detail.fixed_ips[0])
    elif floatingip:
        fip_detail = cc_util_instance.retrieve_floatingip_detail(tenant_id=tenant_id, floatingip=floatingip)
        if fip_detail:
            port_detail = cc_util_instance.retrieve_port_detail(tenant_id=tenant_id, port_id=fip_detail.port_id)

    if port_detail:
        subnet_detail = cc_util_instance.retrieve_subnet_detail(tenant_id, port_detail.subnet_id)

    return port_detail, fip_detail, subnet_detail


class CCUtil:
    def __init__(self, cc_srv_url):
        self.cc_client_instance = cc_http_client.CCHTTPClient(cc_srv_url)

    def retrieve_floatingip_detail(self, tenant_id, floatingip=None, fixed_ip=None, subnet_id=None, **kwargs):
        fip_detail_info = None
        cc_response = None
        if tenant_id and floatingip:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribeFloatingips', {"tenant_id": tenant_id,
                                        "filter": [{"field": "floating_ip_address", "value": floatingip}]})
        elif tenant_id and fixed_ip and subnet_id:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribeFloatingips', {"tenant_id": tenant_id,
                                        "filter": [{"field": "subnet_id", "value": subnet_id},
                                                   {"field": "fixed_ip_address", "value": fixed_ip}]})
        if cc_response and cc_response.code == 0 and cc_response.data['total_count'] > 0:
            fip_detail_info = cc_objs.FloatingipDetailInfo(**cc_response.data['elements'][0])

        return fip_detail_info

    def retrieve_port_detail(self, tenant_id, port_id=None, instanceid=None, **kwargs):
        port_detail_info = None
        if tenant_id and port_id:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribePort', {"tenant_id": tenant_id, "id": port_id})
            if cc_response is not None and cc_response.code == 0:
                port_detail_info = cc_objs.PortDetailInfo(**cc_response.data)

        elif tenant_id and instanceid:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribePorts', {"tenant_id": tenant_id, "filter": [{"field": "device_id", "value": instanceid}]})
            if cc_response and cc_response.code == 0 and cc_response.data['total_count'] > 0:
                port_detail_info = cc_objs.PortDetailInfo(**cc_response.data['elements'][0])

        return port_detail_info

    def retrieve_vpc_detail(self, tenant_id, vpc_id):
        if tenant_id is not None and vpc_id is not None:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribeVpc', {"tenant_id": tenant_id, "id": vpc_id})
            if cc_response is not None and cc_response.code == 0:
                return cc_objs.VpcDetailInfo(**cc_response.data)
        return None

    def retrieve_subnet_detail(self, tenant_id, subnet_id):
        if tenant_id is not None and subnet_id is not None:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribeSubnet', {"tenant_id": tenant_id, "id": subnet_id})
            if cc_response is not None and cc_response.code == 0:
                return cc_objs.SubnetDetailInfo(**cc_response.data)
        return None

    def retrieve_aclrules_detail(self, tenant_id, acl_id):
        if tenant_id is not None and acl_id is not None:
            cc_response = self.cc_client_instance.do_http_request(
                'ListNetworkAclRules', {"tenant_id": tenant_id, "acl_id": acl_id})
            if cc_response is not None and cc_response.code == 0:
                acl_rules_list = []
                data_elements = cc_response.data['elements']
                for element in data_elements:
                    acl_rules_list.append(cc_objs.AclRuleInfo(**element))
                return acl_rules_list
        return None

    def retrieve_sgrules_detail(self, tenant_id, security_group_id):
        if tenant_id is not None and security_group_id is not None:
            cc_response = self.cc_client_instance.do_http_request(
                'DescribeSecurityGroupRules', {"tenant_id": tenant_id,
                                               "filter": [{"field": "securitygroup_id", "value": security_group_id}]})
            if cc_response is not None and cc_response.code == 0:
                sg_rules_list = []
                data_elements = cc_response.data['elements']
                for element in data_elements:
                    sg_rules_list.append(cc_objs.SecurityGroupRuleInfo(**element))
                return sg_rules_list
        return None

    def retrieve_vrbinding_detail(self, vpc_id):
        if vpc_id is not None:
            cc_response = self.cc_client_instance.do_http_request(
                'ListHostsBindingRouter', {"vpc_id": vpc_id})
            if cc_response is not None and cc_response.code == 0:
                vr_host_list = []
                data_elements = cc_response.data
                for element in data_elements:
                    vr_host_list.append(cc_objs.VRBindingInfo(**element))
                return vr_host_list
        return None

    def retrieve_dr_host_list(self):
        cc_response = self.cc_client_instance.do_http_request(
            'DescribeHosts', {})
        if cc_response is not None and cc_response.code == 0:
            dr_host_list = []
            data_elements = cc_response.data['elements']
            for element in data_elements:
                host_info = cc_objs.HostInfo(**element)
                if host_info.type == 'DR':
                    dr_host_list.append(host_info)
            return dr_host_list
        return None
