import json


class PortDetailInfo:
    type_map = {0: 'compute', 1: 'gateway', 2: 'dhcp', 4: 'relay', 8: 'inat'}

    def __init__(self, id, host_ids, subnet_id, tenant_id, type, securitygroup_ids,
                 rate, mac_address, fixed_ips, **kwargs):
        self.id = id
        self.host_ids = host_ids
        self.subnet_id = subnet_id
        self.tenant_id = tenant_id
        self.type = self.type_map[type]
        self.securitygroup_ids = securitygroup_ids
        self.rate = rate
        self.mac_address = mac_address
        self.fixed_ips = fixed_ips

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)


class VpcDetailInfo:
    def __init__(self, id, name, vni, subnet_count, device_count, route_table_count,
                 nat_count, vpn_count, acl_count, sg_count, cidr, **kwargs):
        self.id = id
        self.name = name
        self.vni = vni
        self.subnet_count = subnet_count
        self.device_count = device_count
        self.route_table_count = route_table_count
        self.nat_count = nat_count
        self.vpn_count = vpn_count
        self.acl_count = acl_count
        self.sg_count = sg_count
        self.cidr = cidr


class SubnetDetailInfo:
    def __init__(self, id, vpc_id, acl_id, cidr, gateway_ip, gateway_mac, mtu, name, route_table_id, **kwargs):
        self.id = id
        self.vpc_id = vpc_id
        self.acl_id = acl_id
        self.cidr = cidr
        self.gateway_ip = gateway_ip
        self.gateway_mac = gateway_mac
        self.mtu = mtu
        self.name = name
        self.route_table_id = route_table_id


class FloatingipDetailInfo:
    def __init__(self, id, provider, segment_id, floating_ip_address, fixed_ip_address,
                 port_id, bandwidth_in, bandwidth_out, burst_in, burst_out, **kwargs):
        self.id = id
        self.provider = provider
        self.segment_id = segment_id
        self.floating_ip_address = floating_ip_address
        self.fixed_ip_address = fixed_ip_address
        self.port_id = port_id
        self.bandwidth_in = bandwidth_in
        self.bandwidth_out = bandwidth_out
        self.burst_in = burst_in
        self.burst_out = burst_out

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)


class AclRuleInfo:
    action_map = {0: 'drop', 1: 'accept'}
    direction_map = {0: 'ingress', 1: 'egress'}
    protocol_map = {1: 'icmp', 6: 'tcp', 17: 'udp', 300: 'all'}
    acl_type_map = {0: 'user', 1: 'default'}

    def __init__(self, id, protocol, ip_version, ip_prefix, port_start, port_end, action, priority,
                 type, direction, acl_id, **kwargs):
        self.id = id
        self.acl_id = acl_id
        self.protocol = self.protocol_map[protocol]
        self.ip_version = ip_version
        self.ip_prefix = ip_prefix
        self.port_start = port_start
        self.port_end = port_end
        self.action = self.action_map[action]
        self.priority = priority
        self.type = self.acl_type_map[type]
        self.direction = self.direction_map[direction]


class SecurityGroupRuleInfo:
    direction_map = {0: 'ingress', 1: 'egress'}
    protocol_map = {1: 'icmp', 6: 'tcp', 17: 'udp', 300: 'all'}
    sg_type_map = {0: 'user', 1: 'default'}

    def __init__(self, id, type, protocol, ip_version, ip_prefix, port_start, port_end,
                 direction, is_default, securitygroup_id, **kwargs):
        self.id = id
        self.securitygroup_id = securitygroup_id
        self.type = self.sg_type_map[type]
        self.protocol = self.protocol_map[protocol]
        self.ip_version = ip_version
        self.ip_prefix = ip_prefix
        self.port_start = port_start
        self.port_end = port_end
        self.direction = self.direction_map[direction]
        self.is_default = is_default


class VRBindingInfo:
    def __init__(self, id, name, ip, load, status, **kwargs):
        self.id = id
        self.name = name
        self.ip = ip
        self.load = load
        self.status = status


class HostInfo:
    host_type_map = {0: 'VS', 1: 'VR', 4: 'DR', 5: 'INAT'}

    def __init__(self, id, name, ip, load, type, **kwargs):
        self.id = id
        self.name = name
        self.ip = ip
        self.load = load
        self.type = self.host_type_map[type]
