import json


class AlbDetailInfo:

    def __init__(self, id, name, tenant_id, vpc_id, securitygroup_ids, flavor_id, image_id, vip,
                 nlb_id, pool_id, status, admin_status, **kwargs):
        self.id = id
        self.name = name
        self.tenant_id = tenant_id
        self.vpc_id = vpc_id
        self.securitygroup_ids = securitygroup_ids
        self.flavor_id = flavor_id
        self.image_id = image_id
        self.vip = vip
        self.nlb_id = nlb_id
        self.pool_id = pool_id
        self.status = status
        self.admin_status = admin_status

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)


class AlbInstanceInfo:

    def __init__(self, id, tenant_id, alb_id, lb_instance_id, ip_addr, vip, heartbeat,
                 host_mgmt_ip, subnet_id, status, **kwargs):
        self.id = id
        self.tenant_id = tenant_id
        self.alb_id = alb_id
        self.lb_instance_id = lb_instance_id
        self.ip_addr = ip_addr
        self.vip = vip
        self.heartbeat = heartbeat
        self.host_mgmt_ip = host_mgmt_ip
        self.subnet_id = subnet_id
        self.status = status

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)


class BackendDetailInfo:
    protocol_map = {-1: 'unknown', 1: 'TCP', 2: 'HTTP', 3: 'HTTPS', 4: 'UDP', 5: 'SSL'}

    def __init__(self, id, name, tenant_id, alb_id, target_group_id, health_check_id, protocol, port,
                 algorithm, session, **kwargs):
        self.id = id
        self.name = name
        self.tenant_id = tenant_id
        self.alb_id = alb_id
        self.target_group_id = target_group_id
        self.health_check_id = health_check_id
        self.protocol = self.protocol_map[protocol]
        self.port = port
        self.algorithm = algorithm
        self.session = session

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)

class ListenerDetailInfo:
    protocol_map = {-1: 'unknown', 1: 'TCP', 2: 'HTTP', 3: 'HTTPS', 4: 'UDP', 5: 'SSL'}
    action_map = {0: 'FORWARD', 1: 'DENY'}

    def __init__(self, id, name, tenant_id, alb_id, urlmap_id, backend_id, protocol, port,
                 action_type, connection_idletime, status, **kwargs):
        self.id = id
        self.name = name
        self.tenant_id = tenant_id
        self.alb_id = alb_id
        self.urlmap_id = urlmap_id
        self.backend_id = backend_id
        self.protocol = self.protocol_map[protocol]
        self.port = port
        self.action_type = self.action_map[action_type]
        self.connection_idletime = connection_idletime
        self.status = status

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)

class TargetInfo:

    def __init__(self, id, tenant_id, target_group_id, instance_id, ip_address, port, weight, **kwargs):
        self.id = id
        self.tenant_id = tenant_id
        self.target_group_id = target_group_id
        self.instance_id = instance_id
        self.ip_address = ip_address
        self.port = port
        self.weight = weight

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)

class HealthCheckInfo:

    def __init__(self, id, tenant_id, type, port, interval, health_retry, unhealth_retry, check_timeout, http, **kwargs):
        self.id = id
        self.tenant_id = tenant_id
        self.type = type
        self.port = port
        self.interval = interval
        self.health_retry = health_retry
        self.unhealth_retry = unhealth_retry
        self.check_timeout = check_timeout
        self.http = http

    def to_json(self):
        return json.dumps(self.__dict__, indent=4)

