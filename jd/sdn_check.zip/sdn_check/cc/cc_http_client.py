import requests
import json
from libs import ops_lib


class CCResponse:
    def __init__(self, code, message, detail, data, **kwargs):
        self.code = code
        self.message = message
        self.detail = detail
        self.data = data


class CCHTTPClient:
    def __init__(self, cc_srv_url):
        self.cc_srv_url = cc_srv_url

    def do_http_request(self, action, data_map):
        r = requests.post(self.cc_srv_url + '?Action=' + action, json=data_map)
        if r.status_code != 200:
            print(ops_lib.BColors.FAIL + "CC Request %s Failed" % action + ops_lib.BColors.ENDC)
            return None
        else:
            json_map = json.loads(r.text)
            cc_response_instance = CCResponse(**json_map)
            return cc_response_instance
