import os


class BColors:
    def __init__(self):
        pass
    '''
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    '''
    HEADER = ''
    OKBLUE = ''
    OKGREEN = ''
    WARNING = ''
    FAIL = ''
    ENDC = ''
    BOLD = ''
    UNDERLINE = ''


def print_info(header, output):
    print(BColors.OKGREEN + "======================    " + header + "    ======================" + BColors.ENDC)
    if output is None:
        print("Not Set")
    else:
        if type(output) == str:
            print(output)
        elif type(output) == list:
            for data in output:
                print(data)
    print('\n')


def cc_parameters_check(parsed_args):
    if not parsed_args.tenant_id:
        print('Tenant ID must be given' + "\n")
        return None

    if not parsed_args.floatingip and not parsed_args.instanceid:
        print('Floatingip of instanceid must be given' + "\n")
        return None

    if not parsed_args.cc_url:
        parsed_args.cc_url = os.environ.get("CC_SERVER_URL", None)

    if not parsed_args.cc_url:
        print('URL of CC Server must be given' + "\n")
        return None

    return parsed_args

def lb_parameters_check(parsed_args):
    if not parsed_args.tenant_id:
        print('Tenant ID must be given' + "\n")
        return None

    if not parsed_args.alb_id:
        print('Alb ID must be given' + "\n")
        return None

    if not parsed_args.cc_url:
        parsed_args.cc_url = os.environ.get("CC_SERVER_URL", None)

    if not parsed_args.lb_url:
        parsed_args.lb_url = os.environ.get("LB_SERVER_URL", None)

    if not parsed_args.cc_url:
        print('URL of CC Server must be given' + "\n")
        return None

    if not parsed_args.lb_url:
        print('URL of LB Server must be given' + "\n")
        return None

    return parsed_args
