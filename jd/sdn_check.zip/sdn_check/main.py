#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging

from cliff.app import App
from cliff.commandmanager import CommandManager
from cliff.help import *

from app import info, security_check, lb_info
from app.vr_check import vr_check

logging.getLogger("requests").setLevel(logging.WARNING)


class GeneApp(App):
    log = logging.getLogger(__name__)

    def __init__(self):
        command = CommandManager('gene.app')
        super(GeneApp, self).__init__(
            description='JCloud Ops App',
            version='0.1',
            command_manager=command,
        )
        commands = {
            'info': info.AppDisplayInfo,
            'security-check': security_check.AppSecurityCheck,
            'vr-check': vr_check.AppVRCheck,
            'lb-info': lb_info.AppLBInfo,
        }
        for k, v in commands.items():
            command.add_command(k, v)

    def initialize_app(self, argv):
        self.log.debug('initialize_app')

    def prepare_to_run_command(self, cmd):
        self.log.debug('prepare_to_run_command %s', cmd.__class__.__name__)

    def clean_up(self, cmd, result, err):
        self.log.debug('clean_up %s', cmd.__class__.__name__)


def main(argv=sys.argv[1:]):
    app = GeneApp()
    return app.run(argv)

if __name__ == "__main__":
    main()

